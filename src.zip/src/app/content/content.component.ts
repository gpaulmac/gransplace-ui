import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http'

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  constructor (private httpService: HttpClient) { }
  arrProducts: string [];
  key: string = 'Date Online'; //set default
  reverse: boolean = false;
  sort(key){
  	this.p=1;
  	this.reverse = false;
  	if(key==1){
  		this.reverse = false;
  	}
	if(key==-1){
  		this.reverse = true;
  	}
    this.key = 'Unit Price';
  }
  p: number = 1;
  ngOnInit () {
    this.httpService.get('../assets/js/sample.json').subscribe(
      data => {
      	this.arrProducts = data as string []; // FILL THE ARRAY WITH DATA.
      	for (var key in this.arrProducts) {
      		this.arrProducts[key]['Unit Price']=parseFloat(this.arrProducts[key]['Unit Price'])
		}
		
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }
}